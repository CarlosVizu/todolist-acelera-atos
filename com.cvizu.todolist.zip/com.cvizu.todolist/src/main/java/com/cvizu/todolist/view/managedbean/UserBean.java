package com.cvizu.todolist.view.managedbean;

import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "manageUser")
@SessionScoped
public class UserBean {
    private String username;
    private List<String> usernames;
    
    public UserBean() {
        usernames = new ArrayList<>();
    }
    
    public void saveUser() {
        if(username != null && !username.isEmpty()) {
            usernames.add(username);
            System.out.println(username);
        }
        username = "";
    }
    
    public void deleteUser(String userRemove) {
        usernames.remove(userRemove);
    }
    
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    
    public List<String> getUsernames() {
        return usernames;
    }
    public void setUsernames(List<String> usernames) {
        this.usernames = usernames;
    }
    
    
}