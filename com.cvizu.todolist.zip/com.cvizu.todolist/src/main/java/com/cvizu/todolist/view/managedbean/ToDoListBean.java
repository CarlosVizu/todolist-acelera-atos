package com.cvizu.todolist.view.managedbean;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import com.cvizu.todolist.view.entity.WorkItem;

@ManagedBean(name = "manageToDoList")
@SessionScoped
public class ToDoListBean {
	@ManagedProperty(value = "#{manageUser}")
	private UserBean userBean;
	private String selectedUsername;
	private List<String> usernames;
	private WorkItem workItem;
	private List<WorkItem> workItems;
	private Long cont = 0L;

	public ToDoListBean() {
		usernames = new ArrayList<String>();
		workItem = new WorkItem();
		workItems = new ArrayList<WorkItem>();
	}

	public void saveWorkItem() {
		if (workItem.getId() == null) {
			workItem.setId(cont);
			cont++;
			workItem.setUsername(selectedUsername);
			workItems.add(workItem);
			System.out.println(workItem.getTitle());
		}
		workItem = new WorkItem();
	}

	public void loadWorkItemForm(WorkItem wItem) {
		workItem = wItem;
	}

	public void deleteWorkItem(WorkItem wItem) {
		workItems.remove(wItem);
	}

	public String getSelectedUsername() {
		return selectedUsername;
	}

	public void setSelectedUsername(String selectedUsername) {
		this.selectedUsername = selectedUsername;
	}

	public List<String> getUsernames() {
		return usernames;
	}

	public void setUsernames(List<String> usernames) {
		this.usernames = usernames;
	}

	public WorkItem getWorkItem() {
		return workItem;
	}

	public void setWorkItem(WorkItem workItem) {
		this.workItem = workItem;
	}

	public List<WorkItem> getWorkItems() {
		return workItems;
	}

	public void setWorkItems(List<WorkItem> workItems) {
		this.workItems = workItems;
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}

	public Long getCont() {
		return cont;
	}

	public void setCont(Long cont) {
		this.cont = cont;
	}
	
	

}